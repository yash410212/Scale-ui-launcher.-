package com.scaleui.launcher.zeroscreen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.scaleui.launcher.core.media.MediaSessionBridge
import com.scaleui.launcher.widgets.music.MusicWidgetLight

/** Zero Screen's music card — reuses the FINAL MusicWidgetLight design + MediaSessionBridge. */
@Composable
fun ZeroMusicWidget(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bridge = remember { MediaSessionBridge(context) }
    val controller by bridge.activeController.collectAsState()

    DisposableEffect(Unit) {
        bridge.refresh()
        onDispose { }
    }

    MusicWidgetLight(
        controller = controller,
        onPlayPause = bridge::togglePlayPause,
        onNext = bridge::skipNext,
        onPrevious = bridge::skipPrevious,
        modifier = modifier,
    )
}
