package com.scaleui.launcher.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.animation.LocalAnimationConfig

/**
 * THE glass-styled container. Every card/surface across Home, Drawer,
 * Folders, Zero Screen, Widgets, and Settings should use this instead of
 * a raw Box/Card with hardcoded colors — that's what makes all 4 themes
 * apply launcher-wide automatically (spec section 4: "built-in themes...
 * applied to the whole launcher") instead of each screen needing its own
 * theme-branching logic.
 *
 * Blur uses Modifier.blur(), which is a no-op on API < 31 (RenderEffect
 * requirement) rather than crashing — on older/low-end devices this
 * naturally degrades to a plain tinted surface, which also happens to
 * match the spec's Animation & Performance requirement to reduce
 * expensive blur on low-end hardware, for free.
 *
 * [shape] defaults to the current theme's corner radius but is
 * overridable per call site (e.g. a fully circular widget).
 *
 * [alphaOverride]: spec section 3 lists App Drawer "Transparency control"
 * as its own separate setting from the Theme system — so a screen with its
 * own transparency slider (App Drawer, Part 5) can pass a value here to
 * override just the alpha, while blur/border/corner radius still come from
 * whichever theme is active. Leave null to use the theme's own alpha.
 *
 * Part 8: when the active theme sets `hasSpecularHighlight` (Liquid
 * Glass), a soft diagonal light streak is drawn across the surface —
 * this is what makes real refractive glass read differently from a flat
 * tinted "Glass" card even at similarly low alpha.
 *
 * Part 9: when the active theme sets `hasCornerHighlight` (Glass), a
 * smaller radial glossy catch-light is drawn in the top-left corner
 * instead of a full diagonal streak — matches the rounder, softer glint
 * seen on the Glass reference cards vs. Liquid Glass's sharper streak.
 *
 * Part 10: when the active theme sets `hasMistVignette` (Blur Mist), a
 * soft radial darkening from center-clear to edge-tinted is drawn instead
 * of any highlight — reads as diffused/misty rather than glossy, matching
 * the heavy-bokeh "Blur/One UI" reference.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(LocalGlassConfig.current.cornerRadius),
    alphaOverride: Float? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val config = LocalGlassConfig.current
    val alpha = alphaOverride ?: config.tintAlpha
    val animationConfig = LocalAnimationConfig.current
    val effectiveBlur = if (animationConfig.blurEnabled) config.blurRadius else 0.dp

    Box(
        modifier = modifier
            .clip(shape)
            .let { base ->
                if (config.borderWidth > Dp.Hairline) {
                    base.border(config.borderWidth, config.borderColor, shape)
                } else {
                    base
                }
            }
            .blur(effectiveBlur)
            .background(config.backgroundTint.copy(alpha = alpha), shape),
    ) {
        if (config.hasSpecularHighlight) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.35f),
                                Color.Transparent,
                                Color.Transparent,
                            ),
                            start = Offset(0f, 0f),
                            end = Offset(600f, 900f),
                        ),
                        shape,
                    ),
            )
        }
        if (config.hasCornerHighlight) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.22f),
                                Color.Transparent,
                            ),
                            center = Offset(40f, 40f),
                            radius = 260f,
                        ),
                        shape,
                    ),
            )
        }
        if (config.hasMistVignette) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.25f),
                            ),
                        ),
                        shape,
                    ),
            )
        }
        content()
    }
}
