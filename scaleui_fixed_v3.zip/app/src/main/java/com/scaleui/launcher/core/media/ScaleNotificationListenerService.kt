package com.scaleui.launcher.core.media

import android.service.notification.NotificationListenerService

/**
 * Empty on purpose — its only job is to exist as a bound
 * NotificationListenerService component so MediaSessionBridge can call
 * MediaSessionManager.getActiveSessions(componentName) and read whatever
 * app is currently playing media (spec: music widgets must connect to
 * "any app", e.g. YT Music). Requires the user to grant Notification
 * Access once in system settings — MediaSessionBridge handles that being
 * ungranted gracefully (empty session list, no crash).
 */
class ScaleNotificationListenerService : NotificationListenerService()
