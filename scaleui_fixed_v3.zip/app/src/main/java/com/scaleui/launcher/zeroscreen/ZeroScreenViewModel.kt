package com.scaleui.launcher.zeroscreen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scaleui.launcher.data.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ZeroScreenViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {
    val briefNote: StateFlow<String> = settingsRepository.briefNote
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    fun onNoteChange(text: String) {
        viewModelScope.launch { settingsRepository.setBriefNote(text) }
    }
}
