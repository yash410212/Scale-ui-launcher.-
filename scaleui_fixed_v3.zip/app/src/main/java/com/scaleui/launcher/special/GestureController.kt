package com.scaleui.launcher.special

/** Configurable gesture -> action mapping (spec section 7: Gesture Control). */
enum class GestureAction { OPEN_DRAWER, OPEN_SETTINGS, OPEN_ZERO_SCREEN, LOCK_SCREEN, NONE }
enum class GestureTrigger { SWIPE_UP, SWIPE_DOWN, DOUBLE_TAP, LONG_PRESS }

/** Sensible defaults matching what Parts 4/11/14 already wired as fixed gestures. */
val DEFAULT_GESTURE_MAP = mapOf(
    GestureTrigger.SWIPE_UP to GestureAction.OPEN_DRAWER,
    GestureTrigger.SWIPE_DOWN to GestureAction.OPEN_ZERO_SCREEN,
    GestureTrigger.LONG_PRESS to GestureAction.OPEN_SETTINGS,
    GestureTrigger.DOUBLE_TAP to GestureAction.LOCK_SCREEN,
)
