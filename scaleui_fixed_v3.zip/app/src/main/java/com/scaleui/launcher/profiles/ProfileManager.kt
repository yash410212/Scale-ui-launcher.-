package com.scaleui.launcher.profiles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scaleui.launcher.data.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Profile switching + PIN gate (spec section 6). Per-app visibility
 * filtering by profile (which apps show in each profile) is Part 17,
 * deliberately not here — this part is just the data structure + switch
 * mechanism + PIN.
 */
class ProfileManager(private val settingsRepository: SettingsRepository) : ViewModel() {

    val currentProfile: StateFlow<Profile> = settingsRepository.currentProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Profile.PROFILE_1)

    val hasPinSet: StateFlow<Boolean> = settingsRepository.hasPinSet
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _pinError = MutableStateFlow(false)
    val pinError: StateFlow<Boolean> = _pinError.asStateFlow()

    fun setPin(pin: String) {
        viewModelScope.launch { settingsRepository.setPin(pin) }
    }

    /** Switches profile immediately if no PIN set; otherwise caller must verifyPin first. */
    fun switchProfileUnlocked(profile: Profile) {
        viewModelScope.launch { settingsRepository.setCurrentProfile(profile) }
    }

    fun attemptSwitchWithPin(target: Profile, enteredPin: String) {
        viewModelScope.launch {
            if (settingsRepository.verifyPin(enteredPin)) {
                _pinError.value = false
                settingsRepository.setCurrentProfile(target)
            } else {
                _pinError.value = true
            }
        }
    }
}
