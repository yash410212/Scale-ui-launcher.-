package com.scaleui.launcher.drawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.LocalIconShape

/**
 * App Drawer icon per the locked final design: white-background icon slot
 * (Pixel-style), label below. [slotShape] defaults from Settings' icon
 * shape (Part 11).
 *
 * Part 17/20: long-press triggers [onLongPress] (visibility/hidden menu +
 * freeze toggle — AppDrawerScreen owns the actual menu UI). [isFrozen]
 * dims the icon and shows a small lock badge (Part 20's App Freezer is a
 * launcher-level soft freeze — real per-app process freezing needs
 * Device Owner privileges a normal launcher doesn't have).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DrawerIcon(
    app: AppInfo,
    onClick: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit = {},
    isFrozen: Boolean = false,
    modifier: Modifier = Modifier,
    slotShape: Shape = LocalIconShape.current.toComposeShape(),
) {
    val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }

    Column(
        modifier = modifier.combinedClickable(onClick = { onClick(app) }, onLongClick = { onLongPress(app) }),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(slotShape)
                .background(Color.White)
                .alpha(if (isFrozen) 0.4f else 1f),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = BitmapPainter(bitmap.asImageBitmap()),
                contentDescription = app.label,
                modifier = Modifier.size(40.dp).padding(2.dp),
            )
            if (isFrozen) {
                Icon(Icons.Filled.Lock, contentDescription = "Frozen", tint = Color.Black, modifier = Modifier.size(16.dp))
            }
        }
        Text(
            text = app.label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp).size(width = 72.dp, height = 16.dp),
        )
    }
}
