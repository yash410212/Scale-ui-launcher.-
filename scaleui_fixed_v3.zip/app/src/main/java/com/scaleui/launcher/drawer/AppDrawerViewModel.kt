package com.scaleui.launcher.drawer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.AppRepository
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.profiles.AppVisibility
import com.scaleui.launcher.profiles.filterForProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * All apps visible in the current profile (Part 17: filtered before search
 * even sees them — a hidden app can't be found via search either).
 */
class AppDrawerViewModel(
    private val appRepository: AppRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    private val visibleApps: StateFlow<List<AppInfo>> = combine(
        appRepository.installedApps,
        settingsRepository.currentProfile,
        settingsRepository.appVisibilityMap,
    ) { apps, profile, visibilityMap -> filterForProfile(apps, profile, visibilityMap) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredApps: StateFlow<List<AppInfo>> = combine(visibleApps, _searchQuery) { apps, query ->
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _transparency = MutableStateFlow(0.15f)
    val transparency: StateFlow<Float> = _transparency.asStateFlow()

    val frozenApps: StateFlow<Set<String>> = settingsRepository.frozenApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    init {
        viewModelScope.launch { appRepository.refresh() }
    }

    fun onSearchQueryChange(query: String) { _searchQuery.value = query }
    fun onTransparencyChange(value: Float) { _transparency.value = value.coerceIn(0f, 1f) }

    fun setAppVisibility(packageName: String, visibility: AppVisibility) {
        viewModelScope.launch { settingsRepository.setAppVisibility(packageName, visibility) }
    }

    fun toggleFrozen(packageName: String) {
        viewModelScope.launch { settingsRepository.toggleFrozen(packageName) }
    }
}
