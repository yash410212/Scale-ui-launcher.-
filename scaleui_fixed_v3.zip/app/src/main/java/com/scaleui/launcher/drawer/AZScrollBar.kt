package com.scaleui.launcher.drawer

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Vertical A-Z strip on the drawer's side edge. Drag (or tap, since a tap
 * is just a drag with one point) to jump the grid to the first app
 * starting with that letter.
 *
 * Only shows letters that actually have at least one app under them
 * ([availableLetters]) — an alphabet full of dead-end letters isn't useful
 * on a small screen. '#' (from AppInfo.sortKey) covers non-letter app names.
 */
@Composable
fun AZScrollBar(
    availableLetters: List<Char>,
    onLetterSelected: (Char) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(20.dp)
            .padding(vertical = 24.dp)
            .pointerInput(availableLetters) {
                detectDragGestures { change, _ ->
                    val index = letterIndexForY(change.position.y, size.height, availableLetters.size)
                    availableLetters.getOrNull(index)?.let(onLetterSelected)
                }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        availableLetters.forEach { letter ->
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = letter.toString(),
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

private fun letterIndexForY(y: Float, containerHeightPx: Int, letterCount: Int): Int {
    if (letterCount == 0 || containerHeightPx == 0) return 0
    val fraction = (y / containerHeightPx).coerceIn(0f, 1f)
    return (fraction * (letterCount - 1)).toInt().coerceIn(0, letterCount - 1)
}
