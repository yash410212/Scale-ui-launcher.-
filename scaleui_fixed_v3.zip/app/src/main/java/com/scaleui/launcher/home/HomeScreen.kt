package com.scaleui.launcher.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.AppLauncher
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.folders.FolderOpenScreen
import com.scaleui.launcher.folders.ScaleFolder
import com.scaleui.launcher.special.DoubleTapLock
import com.scaleui.launcher.special.GestureAction
import com.scaleui.launcher.special.GestureTrigger

/**
 * Entry point for the Home Screen feature.
 *
 * Part 18: the 4 gestures (swipe up/down, long-press, double-tap) now
 * dispatch through [gestureMap] (Settings-configurable, Part 18) instead
 * of being hardcoded to one action each — LOCK_SCREEN routes to
 * [DoubleTapLock]. [onOpenDrawer]/[onOpenSettings]/[onOpenZeroScreen] are
 * still plain nav callbacks; this screen just decides WHICH gesture calls
 * which one (or locks) based on the map.
 */
@Composable
fun HomeScreen(
    viewModel: HomePagerViewModel,
    settingsRepository: SettingsRepository,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenZeroScreen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val pages by viewModel.pages.collectAsState()
    val gestureMap by settingsRepository.gestureMap.collectAsState(initial = com.scaleui.launcher.special.DEFAULT_GESTURE_MAP)
    val homeWidgets by settingsRepository.homeWidgets.collectAsState(initial = emptyList())
    var openFolder by remember { mutableStateOf<ScaleFolder?>(null) }
    var accumulatedDrag = 0f
    var swipeDispatched = false

    fun dispatch(action: GestureAction) {
        when (action) {
            GestureAction.OPEN_DRAWER -> onOpenDrawer()
            GestureAction.OPEN_SETTINGS -> onOpenSettings()
            GestureAction.OPEN_ZERO_SCREEN -> onOpenZeroScreen()
            GestureAction.LOCK_SCREEN -> DoubleTapLock.lockNow(context)
            GestureAction.NONE -> Unit
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        BackHandler(enabled = openFolder != null) { openFolder = null }

        HomePager(
            pages = pages,
            onAppClick = { app: AppInfo -> AppLauncher.launch(context, app) },
            onFolderClick = { openFolder = it },
            onMoveApp = viewModel::moveApp,
            homeWidgets = homeWidgets,
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = {
                            accumulatedDrag = 0f
                            swipeDispatched = false
                        },
                        onVerticalDrag = { change, dragAmount ->
                            accumulatedDrag += dragAmount
                            if (!swipeDispatched && accumulatedDrag < -SWIPE_THRESHOLD_PX) {
                                swipeDispatched = true
                                dispatch(gestureMap[GestureTrigger.SWIPE_UP] ?: GestureAction.NONE)
                                change.consume()
                            } else if (!swipeDispatched && accumulatedDrag > SWIPE_THRESHOLD_PX) {
                                swipeDispatched = true
                                dispatch(gestureMap[GestureTrigger.SWIPE_DOWN] ?: GestureAction.NONE)
                                change.consume()
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = { dispatch(gestureMap[GestureTrigger.LONG_PRESS] ?: GestureAction.NONE) },
                        onDoubleTap = { dispatch(gestureMap[GestureTrigger.DOUBLE_TAP] ?: GestureAction.NONE) },
                    )
                },
        )

        openFolder?.let { folder ->
            FolderOpenScreen(folder = folder, onDismiss = { openFolder = null })
        }
    }
}

private const val SWIPE_THRESHOLD_PX = 140f
