package com.scaleui.launcher.widgets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.media.MediaSessionBridge
import com.scaleui.launcher.widgets.clock.ClockWidget
import com.scaleui.launcher.widgets.music.MusicWidgetDark
import com.scaleui.launcher.widgets.music.MusicWidgetLight
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

enum class ScaleWidgetType { CLOCK, MUSIC_DARK, MUSIC_LIGHT }
enum class WidgetSize(val scale: Float) { SMALL(0.65f), MEDIUM(0.82f), LARGE(1f) }
data class WidgetPlacement(val type: ScaleWidgetType, val size: WidgetSize = WidgetSize.MEDIUM)

@Composable
fun ScaleWidgetCard(
    placement: WidgetPlacement,
    onRemove: () -> Unit = {},
    onResize: (WidgetSize) -> Unit = {},
    modifier: Modifier = Modifier,
    showControls: Boolean = true,
) {
    val context = LocalContext.current
    val bridge = remember { MediaSessionBridge(context) }
    val controller by bridge.activeController.collectAsState()
    Column(modifier = modifier.fillMaxWidth().graphicsLayer { scaleX = placement.size.scale; scaleY = placement.size.scale }) {
        when (placement.type) {
            ScaleWidgetType.CLOCK -> ClockWidget()
            ScaleWidgetType.MUSIC_DARK -> MusicWidgetDark(controller, bridge::togglePlayPause, bridge::skipNext, bridge::skipPrevious)
            ScaleWidgetType.MUSIC_LIGHT -> MusicWidgetLight(controller, bridge::togglePlayPause, bridge::skipNext, bridge::skipPrevious)
        }
        if (showControls) Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            WidgetSize.values().forEach { size ->
                FilterChip(selected = placement.size == size, onClick = { onResize(size) }, label = { Text(size.name.lowercase()) })
            }
            Button(onClick = onRemove, modifier = Modifier.padding(start = 6.dp)) { Text("Remove") }
        }
    }
}
