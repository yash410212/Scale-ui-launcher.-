package com.scaleui.launcher.profiles

/** Two launcher-level profiles (spec section 6). Not real Android User/Work Profile isolation. */
enum class Profile { PROFILE_1, PROFILE_2 }
