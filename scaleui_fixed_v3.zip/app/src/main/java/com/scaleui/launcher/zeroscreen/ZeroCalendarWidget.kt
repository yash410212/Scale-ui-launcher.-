package com.scaleui.launcher.zeroscreen

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Zero Screen's compact calendar card — today's full date; a real month-grid view is a later refinement. */
@Composable
fun ZeroCalendarWidget(modifier: Modifier = Modifier) {
    val format = dateFormatter()
    GlassSurface(modifier = modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(16.dp)) {
            Text("Calendar", style = MaterialTheme.typography.titleSmall)
            Text(format.format(Date()), style = MaterialTheme.typography.bodyLarge)
        }
    }
}

private fun dateFormatter() = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
