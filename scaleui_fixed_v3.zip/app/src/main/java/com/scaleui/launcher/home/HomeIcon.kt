package com.scaleui.launcher.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.LocalIconShape

/**
 * A single home-screen icon: app image + label underneath, tap to launch.
 *
 * Part 11: the icon is now clipped to `LocalIconShape.current` (Settings >
 * Home Screen Controls > Icon Shape) instead of always rendering the raw
 * (usually square/adaptive) system icon — same shape source DrawerIcon
 * reads, so Home and Drawer always match.
 */
@Composable
fun HomeIcon(
    app: AppInfo,
    onClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
    val shape = LocalIconShape.current.toComposeShape()

    Column(
        modifier = modifier.clickable { onClick(app) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = BitmapPainter(bitmap.asImageBitmap()),
            contentDescription = app.label,
            modifier = Modifier
                .size(52.dp)
                .clip(shape),
        )
        Text(
            text = app.label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.size(width = 64.dp, height = 16.dp),
        )
    }
}
