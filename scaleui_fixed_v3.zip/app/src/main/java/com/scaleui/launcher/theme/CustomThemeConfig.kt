package com.scaleui.launcher.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * User-tunable values for ThemeMode.CUSTOM (spec section 4: background,
 * transparency, blur, icon appearance, cards, colors, other visual
 * properties). Only the fields ThemeEngine already knows how to apply
 * (via GlassConfig) are here for now — icon appearance / card-specific
 * overrides get added as those systems exist (icon shape in Part 11,
 * card styling as widgets solidify in Part 15).
 *
 * Not persisted yet — DataStore wiring happens in Part 11 alongside the
 * rest of Settings. Until then this just holds sensible defaults so
 * CUSTOM mode is selectable and visibly does something.
 */
data class CustomThemeConfig(
    val backgroundTint: Color = Color.Black,
    val transparency: Float = 0.3f,
    val blurRadius: Dp = 16.dp,
    val borderColor: Color = Color.White,
    val cornerRadius: Dp = 20.dp,
)
